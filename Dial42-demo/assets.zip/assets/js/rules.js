/* =====================================================================
 * rules.js – helpers + business rules shared by all three views.
 *
 *   SBUtil  – escaping, time maths, labels
 *   SBRules – validation of assignment changes (errors / warnings)
 *   SBToast – top-right toast notifications
 *
 * The rules mirror the production "StandBy > Update Schedule" screen.
 * ===================================================================== */

/* ---------------------------------------------------------------------
 * SBUtil – small shared helpers
 * ------------------------------------------------------------------- */
var SBUtil = (function () {
    'use strict';

    var DAY = 1440;   // minutes in a day
    var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

    /* Escape any value for safe insertion into HTML. */
    function esc(v) {
        return String(v === null || v === undefined ? '' : v).replace(/[&<>"']/g, function (c) { return ESC[c]; });
    }

    function isTime(t) { return typeof t === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(t); }

    /* "HH:MM" -> minutes after midnight (NaN when invalid). */
    function toMin(t) {
        if (!isTime(t)) { return NaN; }
        return (+t.substr(0, 2)) * 60 + (+t.substr(3, 2));
    }

    /* minutes -> "HH:MM" (wraps around midnight; 1440 is shown as "24:00" when allow24). */
    function fmt(min, allow24) {
        if (allow24 && min === DAY) { return '24:00'; }
        min = ((Math.round(min) % DAY) + DAY) % DAY;
        var h = Math.floor(min / 60), m = min % 60;
        return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
    }

    /* A shift as one or two [start, end) minute ranges inside 0..1440.
     * end <= start means the shift runs past midnight (22:00–06:00). */
    function segments(start, end) {
        var s = toMin(start), e = toMin(end);
        if (isNaN(s) || isNaN(e)) { return []; }
        if (e > s) { return [[s, e]]; }
        return [[s, DAY], [0, e]].filter(function (r) { return r[1] > r[0]; });
    }

    /* Do two shifts overlap? Handles shifts that cross midnight. */
    function overlaps(aStart, aEnd, bStart, bEnd) {
        var a = segments(aStart, aEnd), b = segments(bStart, bEnd);
        for (var i = 0; i < a.length; i++) {
            for (var j = 0; j < b.length; j++) {
                if (Math.max(a[i][0], b[j][0]) < Math.min(a[i][1], b[j][1])) { return true; }
            }
        }
        return false;
    }

    function timeRange(start, end) { return (start || '--:--') + ' - ' + (end || '--:--'); }

    /* "Amit Sir Corporate / Powai" */
    function placeLabel(locationId) {
        var loc = SBData.location(locationId);
        if (!loc) { return '(no location)'; }
        var corp = SBData.corporate(loc.corporate_id);
        return (corp ? corp.corporatename : '?') + ' / ' + loc.location_title;
    }

    function initials(name) {
        var p = String(name || '').trim().split(/\s+/);
        return ((p[0] || '').charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase();
    }

    /* Stable avatar colour for a name. */
    var COLORS = ['#2c9bae', '#6c0a10', '#26B99A', '#3498DB', '#9B59B6', '#E67E22', '#34495E', '#16A085', '#C0392B', '#7F8C8D'];
    function color(name) {
        var h = 0, s = String(name || '');
        for (var i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) % 9973; }
        return COLORS[h % COLORS.length];
    }

    /* Day / Evening / Night bucket by shift start time (used by filters). */
    function bucket(start) {
        var s = toMin(start);
        if (s >= 360 && s < 840) { return 'day'; }       // 06:00 – 13:59
        if (s >= 840 && s < 1320) { return 'evening'; }  // 14:00 – 21:59
        return 'night';                                  // 22:00 – 05:59
    }

    /* Copy a mapping into the "change" shape used by SBRules / SBData. */
    function toChange(m) {
        return {
            mapping_id: m.id, driver_id: m.driver_id, location_id: m.location_id,
            shift_type: m.shift_type, shift_start_time: m.shift_start_time, shift_end_time: m.shift_end_time
        };
    }

    /* <option> list of locations grouped by corporate. */
    function locationOptions(selectedId, corporateId) {
        var html = '';
        SBData.corporates().forEach(function (c) {
            if (corporateId && c.id !== +corporateId) { return; }
            html += '<optgroup label="' + esc(c.corporatename) + '">';
            SBData.locations(c.id).forEach(function (l) {
                html += '<option value="' + l.id + '"' + (l.id === +selectedId ? ' selected' : '') + '>' + esc(l.location_title) + '</option>';
            });
            html += '</optgroup>';
        });
        return html;
    }

    return {
        DAY: DAY, esc: esc, isTime: isTime, toMin: toMin, fmt: fmt, segments: segments, overlaps: overlaps,
        timeRange: timeRange, placeLabel: placeLabel, initials: initials, color: color, bucket: bucket, toChange: toChange,
        locationOptions: locationOptions
    };
}());


/* ---------------------------------------------------------------------
 * SBRules – validation shared by all views
 *
 * validate(changes) -> [{ errors: [..], warnings: [..] }, ...] (same order)
 *   change = { mapping_id (null for a new assignment), driver_id, location_id,
 *              shift_type, shift_start_time, shift_end_time }
 *
 * ERRORS block the save, WARNINGS allow it after review.
 * ------------------------------------------------------------------- */
var SBRules = (function (U) {
    'use strict';

    function driverName(id) { var d = SBData.driver(id); return d ? d.full_name : 'Driver #' + id; }

    function validate(changes) {
        var batchIds = {};
        changes.forEach(function (c) { if (c.mapping_id) { batchIds[c.mapping_id] = true; } });

        // Mappings NOT touched by this batch keep their current values.
        var untouched = SBData.mappings().filter(function (m) { return !batchIds[m.id]; });

        var results = changes.map(function () { return { errors: [], warnings: [] }; });

        /* ---- Errors ---- */
        changes.forEach(function (c, i) {
            var r = results[i];
            var startOk = U.isTime(c.shift_start_time), endOk = U.isTime(c.shift_end_time);

            if (!c.location_id || !SBData.location(c.location_id)) {
                r.errors.push('Select a destination location.');
            }
            if (!startOk) { r.errors.push('Start time is missing or invalid.'); }
            if (!endOk) { r.errors.push('End time is missing or invalid.'); }
            if (startOk && endOk && c.shift_start_time === c.shift_end_time) {
                r.errors.push('Start and end time cannot be the same.');
            }

            if (c.mapping_id) {
                var orig = SBData.mapping(c.mapping_id);
                if (orig && orig.location_id === +c.location_id && orig.shift_type === c.shift_type &&
                        orig.shift_start_time === c.shift_start_time && orig.shift_end_time === c.shift_end_time) {
                    r.errors.push('Nothing changed – pick a different location, shift type or timing.');
                }
            }

            if (c.location_id) {
                untouched.forEach(function (m) {
                    if (m.driver_id === +c.driver_id && m.location_id === +c.location_id) {
                        r.errors.push('Driver is already assigned to ' + U.placeLabel(m.location_id) +
                            ' (' + U.timeRange(m.shift_start_time, m.shift_end_time) + ').');
                    }
                });
                for (var j = 0; j < changes.length; j++) {
                    if (j !== i && +changes[j].driver_id === +c.driver_id && +changes[j].location_id === +c.location_id) {
                        r.errors.push('This driver is moved to ' + U.placeLabel(c.location_id) + ' twice in this batch.');
                        break;
                    }
                }
            }
        });

        /* ---- Warnings (only for rows without errors) ---- */
        // Projected state = untouched mappings + the batch rows as they will be saved.
        var projected = untouched.map(function (m) { return $.extend({ batchIndex: -1 }, m); });
        changes.forEach(function (c, i) {
            if (!results[i].errors.length) {
                projected.push($.extend({ batchIndex: i }, c, { driver_id: +c.driver_id, location_id: +c.location_id }));
            }
        });

        changes.forEach(function (c, i) {
            var r = results[i];
            if (r.errors.length) { return; }
            var s = c.shift_start_time, e = c.shift_end_time;

            projected.forEach(function (p) {
                if (p.batchIndex === i) { return; }
                if (!U.overlaps(s, e, p.shift_start_time, p.shift_end_time)) { return; }

                // 1. Overlaps the driver's own shift at another location.
                if (p.driver_id === +c.driver_id && p.location_id !== +c.location_id) {
                    r.warnings.push("Overlaps with the driver's shift at " + U.placeLabel(p.location_id) +
                        ' (' + U.timeRange(p.shift_start_time, p.shift_end_time) + ').');
                }

                if (c.shift_type !== 'Permanent' || p.location_id !== +c.location_id || p.shift_type !== 'Permanent' ||
                        p.driver_id === +c.driver_id) { return; }

                // 2. Destination already has an overlapping Permanent driver
                //    (drivers moving out in this batch are not in "untouched", so they don't count).
                if (p.batchIndex === -1) {
                    r.warnings.push(U.placeLabel(c.location_id) + ' already has a Permanent driver in this time: ' +
                        driverName(p.driver_id) + ' (' + U.timeRange(p.shift_start_time, p.shift_end_time) + ').');
                } else {
                // 3. Two drivers in this batch both Permanent, overlapping, at the same location.
                    r.warnings.push('Both this driver and ' + driverName(p.driver_id) + ' are set to Permanent at ' +
                        U.placeLabel(c.location_id) + ' with overlapping shifts.');
                }
            });
        });

        return results;
    }

    /* Warnings for the CURRENT data (used to flag existing blocks/cards). */
    function currentWarnings() {
        var all = SBData.mappings(), out = {};
        all.forEach(function (m) {
            var w = [];
            all.forEach(function (o) {
                if (o.id === m.id || !U.overlaps(m.shift_start_time, m.shift_end_time, o.shift_start_time, o.shift_end_time)) { return; }
                if (o.driver_id === m.driver_id && o.location_id !== m.location_id) {
                    w.push("Overlaps with the driver's shift at " + U.placeLabel(o.location_id) +
                        ' (' + U.timeRange(o.shift_start_time, o.shift_end_time) + ').');
                } else if (o.location_id === m.location_id && m.shift_type === 'Permanent' && o.shift_type === 'Permanent' &&
                        o.driver_id !== m.driver_id) {
                    w.push('Another Permanent driver overlaps at this location: ' + driverName(o.driver_id) +
                        ' (' + U.timeRange(o.shift_start_time, o.shift_end_time) + ').');
                }
            });
            if (w.length) { out[m.id] = w; }
        });
        return out;
    }

    /* Plain-English description of one change (used for toasts + "Recent changes"). */
    function describe(c) {
        var name = driverName(c.driver_id);
        var orig = c.mapping_id ? SBData.mapping(c.mapping_id) : null;
        var newTime = U.timeRange(c.shift_start_time, c.shift_end_time);
        if (!orig) {
            return 'Assigned ' + name + ' to ' + U.placeLabel(c.location_id) + ' (' + c.shift_type + ', ' + newTime + ')';
        }
        var parts = [];
        if (orig.location_id !== +c.location_id) {
            parts.push('moved ' + U.placeLabel(orig.location_id) + ' → ' + U.placeLabel(c.location_id));
        }
        if (orig.shift_type !== c.shift_type) { parts.push(orig.shift_type + ' → ' + c.shift_type); }
        if (orig.shift_start_time !== c.shift_start_time || orig.shift_end_time !== c.shift_end_time) {
            parts.push(U.timeRange(orig.shift_start_time, orig.shift_end_time) + ' → ' + newTime);
        }
        return name + ': ' + (parts.join(', ') || 'no change');
    }

    /* Label for a batch of changes. */
    function describeBatch(changes) {
        if (changes.length === 1) { return describe(changes[0]); }
        var names = changes.map(function (c) { return driverName(c.driver_id); });
        return 'Updated ' + changes.length + ' assignments (' + names.join(', ') + ')';
    }

    /* <ul> of messages for inline display. */
    function messagesHtml(res) {
        var html = '';
        res.errors.forEach(function (m) { html += '<li class="sb-msg-error"><i class="fa fa-times-circle"></i> ' + U.esc(m) + '</li>'; });
        res.warnings.forEach(function (m) { html += '<li class="sb-msg-warning"><i class="fa fa-exclamation-triangle"></i> ' + U.esc(m) + '</li>'; });
        return html ? '<ul class="sb-msgs">' + html + '</ul>' : '';
    }

    return {
        validate: validate, currentWarnings: currentWarnings, describe: describe,
        describeBatch: describeBatch, messagesHtml: messagesHtml, driverName: driverName
    };
}(SBUtil));


/* ---------------------------------------------------------------------
 * SBToast – SBToast.show('Saved', 'success' | 'error' | 'warning' | 'info')
 * ------------------------------------------------------------------- */
var SBToast = (function ($, U) {
    'use strict';
    var ICONS = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };

    function show(message, type, title) {
        type = ICONS[type] ? type : 'info';
        var $box = $('#sb-toasts');
        if (!$box.length) { $box = $('<div id="sb-toasts" aria-live="polite"></div>').appendTo('body'); }
        var $t = $('<div class="sb-toast sb-toast-' + type + '" role="status">' +
            '<i class="fa ' + ICONS[type] + '"></i>' +
            '<div class="sb-toast-text">' + (title ? '<strong>' + U.esc(title) + '</strong>' : '') + U.esc(message) + '</div>' +
            '<button type="button" class="sb-toast-close" aria-label="Close">&times;</button></div>');
        $box.prepend($t);
        $box.children('.sb-toast').slice(3).remove();   // keep at most 3 on screen
        setTimeout(function () { $t.addClass('in'); }, 10);
        var close = function () { $t.removeClass('in'); setTimeout(function () { $t.remove(); }, 250); };
        $t.find('.sb-toast-close').on('click', close);
        setTimeout(close, type === 'error' || type === 'warning' ? 6000 : 3500);
    }

    return { show: show };
}(jQuery, SBUtil));
