/* =====================================================================
 * view2.js – VIEW 2 "Calendar"
 * X-axis = locations of one corporate, Y-axis = 00:00–24:00.
 * Drag a block to move it (time and/or location), drag its edges to resize,
 * click it to edit, click an empty slot to assign a driver.
 * Uses pointer events, so it works with mouse and touch (no libraries).
 * ===================================================================== */
var SBView2 = (function ($, U, R) {
    'use strict';

    var SLOT_PX = { 30: 26, 60: 44 };   // pixel height of one slot per zoom level
    var SNAP = 15;                      // drag/resize snap in minutes
    var MIN_LEN = 15;                   // shortest shift you can resize to

    var corpId = 1;
    var zoom = 30;
    var $scroller;
    var drag = null;                    // active block drag/resize
    var chipDrag = null;                // active "unassigned driver" chip drag
    var suppressClickUntil = 0;
    var scrollToMin = 7 * 60;           // initial scroll position (07:00)
    var drawer = { open: false, mode: 'edit', mappingId: null, ack: false };

    function ppm() { return SLOT_PX[zoom] / zoom; }   // pixels per minute
    function snap(min) { return Math.round(min / SNAP) * SNAP; }
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

    /* ---------- toolbar ---------- */
    function fillToolbar() {
        var html = '';
        SBData.corporates().forEach(function (c) {
            html += '<option value="' + c.id + '">' + U.esc(c.corporatename) + '</option>';
        });
        $('#v2-corp').html(html).val(corpId);
        var corp = SBData.corporate(corpId);
        $('#v2-company').val(corp ? corp.companyname : '');
    }

    /* ---------- block layout: overlapping blocks sit side by side ---------- */
    function layoutColumn(locationId) {
        var items = [];
        SBData.mappingsAt(locationId).forEach(function (m) {
            var segs = U.segments(m.shift_start_time, m.shift_end_time);
            segs.forEach(function (s, i) {
                items.push({ m: m, s: s[0], e: s[1], part: segs.length > 1 ? (i === 0 ? 'first' : 'second') : 'only' });
            });
        });
        items.sort(function (a, b) { return a.s - b.s || b.e - a.e; });

        var cluster = [], lanes = [], clusterEnd = -1;
        function close() { cluster.forEach(function (it) { it.lanes = lanes.length; }); cluster = []; lanes = []; }
        items.forEach(function (it) {
            if (it.s >= clusterEnd) { close(); }
            var lane = 0;
            while (lane < lanes.length && lanes[lane] > it.s) { lane++; }
            lanes[lane] = it.e;
            it.lane = lane;
            cluster.push(it);
            clusterEnd = Math.max(clusterEnd, it.e);
        });
        close();
        return items;
    }

    function blockHtml(it, warnings) {
        var m = it.m, d = SBData.driver(m.driver_id), w = warnings[m.id];
        var p = ppm(), top = it.s * p, h = Math.max((it.e - it.s) * p, 16) - 1;
        var width = 100 / it.lanes, left = it.lane * width;
        var range = m.shift_start_time + '–' + m.shift_end_time;
        var timeTxt = it.part === 'first' ? U.esc(range) + ' <span class="b-cont">↪</span>' :
                      it.part === 'second' ? '<span class="b-cont">↪</span> ' + U.esc(range) : U.esc(range);
        var tip = d.full_name + ' (' + d.mobile_no + ')\n' + m.shift_type + ', ' + U.timeRange(m.shift_start_time, m.shift_end_time) +
                  (it.part !== 'only' ? ' – runs past midnight' : '') + (w ? '\n\n⚠ ' + w.join('\n⚠ ') : '') +
                  '\n\nDrag to move · drag edges to resize · click to edit';
        return '<div class="v2-block ' + (m.shift_type === 'Permanent' ? 'perm' : 'rel') + (w ? ' warn' : '') + '"' +
            ' data-id="' + m.id + '" data-part="' + it.part + '" title="' + U.esc(tip) + '"' +
            ' style="top:' + top + 'px;height:' + h + 'px;left:calc(' + left + '% + 2px);width:calc(' + width + '% - 4px)">' +
            (it.part !== 'second' ? '<div class="v2-h-top"></div>' : '') +
            (it.part !== 'first' ? '<div class="v2-h-bot"></div>' : '') +
            (w ? '<span class="b-warn"><i class="fa fa-exclamation"></i></span>' : '') +
            '<div class="b-name">' + U.esc(d.full_name) + '</div>' +
            '<div class="b-meta">' + timeTxt + '</div>' +
            '<div class="b-meta">' + U.esc(d.mobile_no) + '</div>' +
            '</div>';
    }

    /* ---------- grid ---------- */
    function render() {
        if (drag || chipDrag) { return; }   // never rebuild under the user's finger
        fillToolbar();
        var el = $scroller[0];
        var keepTop = el.scrollTop, keepLeft = el.scrollLeft;
        var locs = SBData.locations(corpId);

        if (!locs.length) {
            $scroller.html('<div class="v2-empty"><i class="fa fa-map-marker fa-2x"></i><br>This corporate has no locations yet.</div>');
            renderUnassigned();
            return;
        }

        var p = ppm(), height = 1440 * p, warnings = R.currentWarnings();
        var head = '<div class="v2-head"><div class="v2-corner">Time</div>';
        var cols = '';
        locs.forEach(function (l) {
            var maps = SBData.mappingsAt(l.id), n = {};
            maps.forEach(function (m) { n[m.driver_id] = true; });
            var count = Object.keys(n).length;
            head += '<div class="v2-colhead" data-loc="' + l.id + '">' +
                '<strong title="' + U.esc(l.location_title) + '">' + U.esc(l.location_title) + '</strong>' +
                '<span class="sb-muted" title="' + U.esc(l.address1 + ', ' + l.address2) + '">' + U.esc(l.address1) + '</span>' +
                '<span class="v2-count"' + (count ? '' : ' style="color:#E74C3C"') + '><i class="fa fa-user"></i> ' +
                    (count ? count + ' driver' + (count > 1 ? 's' : '') : 'No driver assigned') + '</span></div>';
            cols += '<div class="v2-col" data-loc="' + l.id + '" style="height:' + height + 'px;' +
                'background-image:linear-gradient(to bottom,#dfe3e7 1px,transparent 1px),linear-gradient(to bottom,#f1f3f5 1px,transparent 1px);' +
                'background-size:100% ' + (60 * p) + 'px,100% ' + (zoom * p) + 'px">' +
                '<div class="v2-slot-hint"></div>' +
                layoutColumn(l.id).map(function (it) { return blockHtml(it, warnings); }).join('') +
                '</div>';
        });
        head += '</div>';

        var times = '';
        for (var t = 0; t <= 1440; t += zoom) {
            var style = 'top:' + (t * p) + 'px' + (t === 0 ? ';transform:none' : '') + (t === 1440 ? ';transform:translateY(-14px)' : '');
            times += '<div class="v2-time' + (t % 60 === 0 ? ' hour' : '') + '" style="' + style + '">' + U.fmt(t, true) + '</div>';
        }

        $scroller.html('<div class="v2-grid" style="min-width:' + (64 + locs.length * 190) + 'px">' + head +
            '<div class="v2-body" style="height:' + height + 'px"><div class="v2-times">' + times + '</div>' +
            '<div class="v2-cols">' + cols + '</div></div></div>');

        if (scrollToMin !== null) {
            // A hidden tab cannot scroll: keep the request until the grid is visible.
            if (el.clientHeight > 0) {
                el.scrollTop = scrollToMin * p;
                el.scrollLeft = 0;
                scrollToMin = null;
            }
        } else {
            el.scrollTop = keepTop;
            el.scrollLeft = keepLeft;
        }
        renderUnassigned();
    }

    function renderUnassigned() {
        var all = SBData.unassignedDrivers();
        var q = $.trim($('#v2-un-q').val()).toLowerCase();
        var list = all.filter(function (d) {
            return !q || d.full_name.toLowerCase().indexOf(q) !== -1 || String(d.mobile_no).indexOf(q) !== -1;
        });
        var html = '';
        $('#v2-un-q').closest('.v2-un-search').toggle(all.length > 0);
        if (!all.length) {
            html += '<span class="sb-muted">Every driver has an assignment. Click an empty slot to add a second one.</span>';
        } else if (!list.length) {
            html += '<span class="sb-muted">No unassigned driver matches "' + U.esc(q) + '".</span>';
        }
        list.forEach(function (d) {
            html += '<span class="sb-chip" data-driver="' + d.id + '" title="Drag onto a location column">' +
                '<span class="sb-ini" style="background:' + U.color(d.full_name) + '">' + U.esc(U.initials(d.full_name)) + '</span>' +
                U.esc(d.full_name) + ' <span class="sb-muted">' + U.esc(d.mobile_no) + '</span></span>';
        });
        if (list.length) { html += '<span class="sb-muted" style="margin-left:auto">Drag a driver onto the grid to assign</span>'; }
        $('#v2-un-list').html(html);
    }

    function flash(mappingId) {
        $scroller.find('.v2-block[data-id="' + mappingId + '"]').addClass('flash');
    }

    function colAt(x, y) {
        var found = null;
        $scroller.find('.v2-col').each(function () {
            var r = this.getBoundingClientRect();
            if (x >= r.left && x < r.right && (y === undefined || (y >= r.top - 60 && y <= r.bottom))) { found = this; }
        });
        return found;
    }

    function minuteAt(col, clientY) {
        return (clientY - col.getBoundingClientRect().top) / ppm();
    }

    function highlight(col) {
        $scroller.find('.drop-hover').removeClass('drop-hover');
        if (col) {
            var loc = $(col).data('loc');
            $(col).addClass('drop-hover');
            $scroller.find('.v2-colhead[data-loc="' + loc + '"]').addClass('drop-hover');
        }
    }

    function tip(text, x, y) {
        var $t = $('#v2-drag-tip');
        if (!$t.length) { $t = $('<div id="v2-drag-tip" class="v2-drag-tip"></div>').appendTo('body'); }
        $t.text(text).css({ left: x + 14, top: y + 14 }).show();
    }
    function hideTip() { $('#v2-drag-tip').remove(); }

    function autoScroll(e) {
        var r = $scroller[0].getBoundingClientRect(), el = $scroller[0];
        if (e.clientY > r.bottom - 30) { el.scrollTop += 14; } else if (e.clientY < r.top + 70) { el.scrollTop -= 14; }
        if (e.clientX > r.right - 30) { el.scrollLeft += 14; } else if (e.clientX < r.left + 90) { el.scrollLeft -= 14; }
    }

    /* ---------- save a change through the shared rules ---------- */
    function commit(change) {
        var res = R.validate([change])[0];
        if (res.errors.length) {
            render();   // snap back
            SBToast.show(res.errors[0], 'error', 'Not saved. ');
            return false;
        }
        var label = R.describe(change);
        SBData.applyChanges([change], label, 'View 2');
        flash(change.mapping_id);
        if (res.warnings.length) {
            SBToast.show(res.warnings.join(' '), 'warning', 'Saved with warning. ');
        } else {
            SBToast.show(label, 'success', 'Saved. ');
        }
        return true;
    }

    /* ---------- block drag / resize ---------- */
    function onBlockDown(e) {
        if (e.button !== 0 || drawer.open) { return; }
        var $b = $(this), m = SBData.mapping($b.data('id'));
        var $t = $(e.target);
        drag = {
            el: this, $b: $b, m: $.extend({}, m), part: $b.data('part'),
            kind: $t.closest('.v2-h-top').length ? 'top' : ($t.closest('.v2-h-bot').length ? 'bot' : 'move'),
            x0: e.clientX, y0: e.clientY, st0: $scroller[0].scrollTop, sl0: $scroller[0].scrollLeft,
            top0: parseFloat(this.style.top), h0: parseFloat(this.style.height), moved: false, result: null
        };
        try { this.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        e.preventDefault();
    }

    function onBlockMove(e) {
        if (!drag) { return; }
        var dx = e.clientX - drag.x0 + ($scroller[0].scrollLeft - drag.sl0);
        var dy = e.clientY - drag.y0 + ($scroller[0].scrollTop - drag.st0);
        if (!drag.moved && Math.abs(dx) < 4 && Math.abs(dy) < 4) { return; }
        if (!drag.moved) { drag.moved = true; drag.$b.addClass('dragging'); }
        autoScroll(e);

        var p = ppm(), delta = snap(dy / p), m = drag.m;
        var s = U.toMin(m.shift_start_time), en = U.toMin(m.shift_end_time);
        var segTop = drag.top0 / p, segBot = segTop + (drag.h0 + 1) / p;   // block's own segment in minutes
        var res = { start: m.shift_start_time, end: m.shift_end_time, loc: m.location_id };

        if (drag.kind === 'move') {
            var col = colAt(e.clientX);
            highlight(col);
            if (col) { res.loc = +$(col).data('loc'); }
            res.start = U.fmt(s + delta);
            res.end = U.fmt(en + delta);
            drag.$b.css('transform', 'translate(' + dx + 'px,' + (delta * p) + 'px)');
        } else if (drag.kind === 'top') {
            var newTop = clamp(snap(segTop + delta), 0, segBot - MIN_LEN);
            res.start = U.fmt(newTop);
            drag.$b.css({ top: newTop * p, height: (segBot - newTop) * p - 1 });
        } else {
            var newBot = clamp(snap(segBot + delta), segTop + MIN_LEN, 1440);
            res.end = U.fmt(newBot);
            drag.$b.css({ height: (newBot - segTop) * p - 1 });
        }
        drag.result = res;
        tip(res.start + ' – ' + res.end + (res.loc !== m.location_id ? '  →  ' + SBData.location(res.loc).location_title : ''), e.clientX, e.clientY);
    }

    function onBlockUp() {
        if (!drag) { return; }
        var d = drag;
        drag = null;
        hideTip();
        highlight(null);
        if (!d.moved) { openEdit(d.m.id); return; }
        suppressClickUntil = Date.now() + 400;

        var r = d.result, m = d.m;
        if (!r || (r.loc === m.location_id && r.start === m.shift_start_time && r.end === m.shift_end_time)) {
            render();
            return;
        }
        commit({
            mapping_id: m.id, driver_id: m.driver_id, location_id: r.loc, shift_type: m.shift_type,
            shift_start_time: r.start, shift_end_time: r.end
        });
    }

    /* ---------- unassigned chip drag ---------- */
    function onChipDown(e) {
        if (e.button !== 0) { return; }
        chipDrag = { el: this, driver: +$(this).data('driver'), x0: e.clientX, y0: e.clientY, moved: false, $ghost: null };
        try { this.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        e.preventDefault();
    }

    function onChipMove(e) {
        if (!chipDrag) { return; }
        if (!chipDrag.moved && Math.abs(e.clientX - chipDrag.x0) < 4 && Math.abs(e.clientY - chipDrag.y0) < 4) { return; }
        if (!chipDrag.moved) {
            chipDrag.moved = true;
            chipDrag.$ghost = $(chipDrag.el).clone().addClass('sb-drag-ghost').appendTo('body');
        }
        chipDrag.$ghost.css({ left: e.clientX - 20, top: e.clientY - 14 });
        var col = colAt(e.clientX, e.clientY);
        highlight(col);
        if (col) {
            var t = U.fmt(clamp(snap(minuteAt(col, e.clientY)), 0, 1425));
            tip(t + '  →  ' + SBData.location($(col).data('loc')).location_title, e.clientX, e.clientY);
        } else {
            hideTip();
        }
    }

    function onChipUp(e) {
        if (!chipDrag) { return; }
        var c = chipDrag;
        chipDrag = null;
        if (c.$ghost) { c.$ghost.remove(); }
        hideTip();
        highlight(null);
        if (!c.moved) {
            var first = SBData.locations(corpId)[0];
            openAssign(first ? first.id : null, 8 * 60, c.driver);
            return;
        }
        var col = colAt(e.clientX, e.clientY);
        if (col) {
            openAssign(+$(col).data('loc'), clamp(snap(minuteAt(col, e.clientY)), 0, 1425), c.driver);
        }
    }

    /* ---------- drawer ---------- */
    function driverOptions(selected, lockedId) {
        var html = '', un = SBData.unassignedDrivers(), unIds = {};
        if (lockedId) {
            var d = SBData.driver(lockedId);
            return '<option value="' + d.id + '">' + U.esc(d.full_name + ' - ' + d.mobile_no) + '</option>';
        }
        html += '<option value="">-- Select driver --</option>';
        if (un.length) {
            html += '<optgroup label="Unassigned drivers">';
            un.forEach(function (d) {
                unIds[d.id] = true;
                html += '<option value="' + d.id + '"' + (d.id === +selected ? ' selected' : '') + '>' + U.esc(d.full_name + ' - ' + d.mobile_no) + '</option>';
            });
            html += '</optgroup>';
        }
        html += '<optgroup label="All drivers (adds another assignment)">';
        SBData.drivers().forEach(function (d) {
            if (unIds[d.id]) { return; }
            html += '<option value="' + d.id + '"' + (d.id === +selected ? ' selected' : '') + '>' + U.esc(d.full_name + ' - ' + d.mobile_no) + '</option>';
        });
        return html + '</optgroup>';
    }

    function fillDrawerCorp(selectedCorp) {
        var html = '';
        SBData.corporates().forEach(function (c) {
            html += '<option value="' + c.id + '"' + (c.id === +selectedCorp ? ' selected' : '') + '>' + U.esc(c.corporatename) + '</option>';
        });
        $('#v2-d-corp').html(html);
    }

    function fillDrawerLoc(selectedLoc) {
        var corp = $('#v2-d-corp').val();
        $('#v2-d-loc').html('<option value="">-- Select location --</option>' + U.locationOptions(selectedLoc, corp));
    }

    function setInfo(corporateId, locationId) {
        var c = SBData.corporate(corporateId), l = SBData.location(locationId);
        $('#v2-d-info').html(
            '<p class="sb-info-line"><b>Standby Corporate</b> - ' + U.esc(c ? c.corporatename : '') + '</p>' +
            '<p class="sb-info-line"><b>Standby Company</b> - ' + U.esc(c ? c.companyname : '') + '</p>' +
            '<p class="sb-info-line"><b>Location</b> - ' + U.esc(l ? l.location_title : '–') + '</p><hr style="margin:10px 0">');
    }

    function resetAck() {
        drawer.ack = false;
        $('#v2-d-save span').text('Save');
        $('#v2-d-msgs').empty();
    }

    function showDrawer() {
        drawer.open = true;
        resetAck();
        $('body').addClass('sb-drawer-open');
        $('#v2-backdrop').fadeIn(150);
        $('#v2-drawer').addClass('open').attr('aria-hidden', 'false');
        setTimeout(function () { $('#v2-drawer').find('select:enabled, input').first().trigger('focus'); }, 230);
    }

    function closeDrawer() {
        drawer.open = false;
        $('body').removeClass('sb-drawer-open');
        $('#v2-backdrop').fadeOut(150);
        $('#v2-drawer').removeClass('open').attr('aria-hidden', 'true');
    }

    function openEdit(id) {
        var m = SBData.mapping(id);
        if (!m) { return; }
        drawer.mode = 'edit';
        drawer.mappingId = id;
        $('#v2-d-title').text('Edit assignment');
        setInfo(m.corporate_id, m.location_id);
        $('#v2-d-driver').html(driverOptions(null, m.driver_id)).prop('disabled', true);
        fillDrawerCorp(m.corporate_id);
        fillDrawerLoc(m.location_id);
        $('#v2-d-type').val(m.shift_type);
        $('#v2-d-start').val(m.shift_start_time);
        $('#v2-d-end').val(m.shift_end_time);
        $('#v2-d-remove').show();
        showDrawer();
    }

    function openAssign(locationId, startMin, driverId) {
        var loc = SBData.location(locationId);
        drawer.mode = 'assign';
        drawer.mappingId = null;
        $('#v2-d-title').text('Assign driver');
        setInfo(loc ? loc.corporate_id : corpId, locationId);
        $('#v2-d-driver').html(driverOptions(driverId)).prop('disabled', false);
        fillDrawerCorp(loc ? loc.corporate_id : corpId);
        fillDrawerLoc(locationId);
        $('#v2-d-type').val('Permanent');
        $('#v2-d-start').val(U.fmt(startMin));
        $('#v2-d-end').val(U.fmt(startMin + 120));
        $('#v2-d-remove').hide();
        showDrawer();
    }

    function drawerSave() {
        var driverId = +$('#v2-d-driver').val();
        if (!driverId) {
            $('#v2-d-msgs').html(R.messagesHtml({ errors: ['Select a driver.'], warnings: [] }));
            return;
        }
        var change = {
            mapping_id: drawer.mode === 'edit' ? drawer.mappingId : null,
            driver_id: driverId,
            location_id: $('#v2-d-loc').val() ? +$('#v2-d-loc').val() : null,
            shift_type: $('#v2-d-type').val(),
            shift_start_time: $('#v2-d-start').val(),
            shift_end_time: $('#v2-d-end').val()
        };
        var res = R.validate([change])[0];
        $('#v2-d-msgs').html(R.messagesHtml(res));
        if (res.errors.length) { return; }
        if (res.warnings.length && !drawer.ack) {
            drawer.ack = true;
            $('#v2-d-save span').text('Save anyway');
            return;
        }

        var label = R.describe(change), name = R.driverName(change.driver_id);
        var newCorp = SBData.location(change.location_id).corporate_id;
        closeDrawer();
        SBData.applyChanges([change], label, 'View 2');
        var saved = change.mapping_id || SBData.mappings().slice(-1)[0].id;
        flash(saved);
        if (newCorp !== corpId) {
            SBToast.show(name + ' moved to ' + U.placeLabel(change.location_id) + '. Switch the corporate to see the block.', 'info', 'Moved to another corporate. ');
        } else {
            SBToast.show(label, res.warnings.length ? 'warning' : 'success', res.warnings.length ? 'Saved with warning. ' : 'Saved. ');
        }
    }

    function drawerRemove() {
        var m = SBData.mapping(drawer.mappingId);
        if (!m) { closeDrawer(); return; }
        var label = 'Removed ' + R.driverName(m.driver_id) + ' from ' + U.placeLabel(m.location_id);
        closeDrawer();
        SBData.removeMapping(m.id, label, 'View 2');
        SBToast.show(label + '.', 'success', 'Removed. ');
    }

    /* ---------- events ---------- */
    function bind() {
        $('#v2-corp').on('change', function () {
            corpId = +$(this).val();
            scrollToMin = 7 * 60;
            render();
        });

        $('#v2 .v2-zoom').on('click', '.btn', function () {
            var topMin = $scroller[0].scrollTop / ppm();
            zoom = +$(this).data('zoom');
            $(this).addClass('active').siblings().removeClass('active');
            scrollToMin = topMin;
            render();
        });

        $scroller.on('pointerdown', '.v2-block', onBlockDown)
            .on('pointermove', '.v2-block', onBlockMove)
            .on('pointerup pointercancel', '.v2-block', onBlockUp);

        // Hover hint + click on an empty slot -> assign
        $scroller.on('pointermove', '.v2-col', function (e) {
            if (drag || chipDrag || $(e.target).closest('.v2-block').length) { $(this).find('.v2-slot-hint').css('visibility', 'hidden'); return; }
            var min = Math.floor(minuteAt(this, e.clientY) / zoom) * zoom;
            $(this).find('.v2-slot-hint').css({ visibility: 'visible', top: min * ppm(), height: zoom * ppm() })
                .text('+ Assign at ' + U.fmt(min));
        });
        $scroller.on('click', '.v2-col', function (e) {
            if (Date.now() < suppressClickUntil || $(e.target).closest('.v2-block').length) { return; }
            var min = Math.floor(minuteAt(this, e.clientY) / zoom) * zoom;
            openAssign(+$(this).data('loc'), min);
        });

        $('#v2-unassigned').on('pointerdown', '.sb-chip', onChipDown)
            .on('pointermove', '.sb-chip', onChipMove)
            .on('pointerup pointercancel', '.sb-chip', onChipUp);
        $('#v2-un-q').on('input', renderUnassigned);

        // Drawer
        $('#v2-d-corp').on('change', function () { fillDrawerLoc(null); });
        $('#v2-drawer').on('change input', '.v2-d-f', resetAck);
        $('#v2-d-save').on('click', drawerSave);
        $('#v2-d-remove').on('click', drawerRemove);
        $('#v2-drawer .v2-d-cancel, #v2-backdrop').on('click', closeDrawer);
        $(document).on('keydown', function (e) { if (e.key === 'Escape' && drawer.open) { closeDrawer(); } });

        $(document).on('sb:change', function (e, reason) {
            if (drawer.open && drawer.mode === 'edit' && !SBData.mapping(drawer.mappingId)) { closeDrawer(); }
            if (reason === 'reset') { scrollToMin = 7 * 60; }
            render();
        });
    }

    return {
        init: function () {
            $scroller = $('#v2-scroller');
            $('#v2-backdrop, #v2-drawer').appendTo('body');
            bind();
            render();
        },
        onShow: function () { render(); }
    };
}(jQuery, SBUtil, SBRules));
